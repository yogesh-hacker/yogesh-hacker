import requests
from bs4 import BeautifulSoup
import re
from django.http import JsonResponse
import json
import ast


default_domain = "https://streamwish.to"
initial_headers = {
    'Referer': default_domain,
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"',
}

response_data = {
    'status': None,
    'status_code': None,
    'error': None,
    'headers': {},
    'streaming_urls': {},
    'downloading_urls': {}
}

proxies = {
    # __ Add your proxies here or use proxy_url __ 
}

# You don't need a proxy if these sites are not blocked in your region.

# Use this if you don't own a proxy it can make proccess longer
proxy_url = f"https://script.google.com/macros/s/AKfycbzo7nCuCR9GWczG2Hk4Uhpstv291rI6pqG9f25sMYkI2R94zURLRNS20blc80MBzh3kOA/exec?header_Referer={default_domain}&header_User-Agent={initial_headers['User-Agent']}"

#Create session
session = requests.Session()

qualities = {
    "_n" : "720p"
}

def real_extract(url):
    # Get the embed page
    initial_response = session.get(url, headers = initial_headers).text
    
    # Getting file regex
    initial_regex = r'file:"([^"]+)"'
    initial_match = re.search(initial_regex, initial_response)
    # Fetch and parse the initial response
    soup = BeautifulSoup(initial_response, 'html.parser')
    js_code = next((script.string for script in soup.find_all('script') if script.string and "eval(function(p,a,c,k,e,d)" in script.string), "")

    # Extract and clean the JS code
    encoded_packed = re.sub(r"eval\(function\([^\)]*\)\{[^\}]*\}\(|.split\('\|'\)\)\)", '', js_code)
    data = ast.literal_eval(encoded_packed)

    # Base-36 conversion helper function
    def to_base_36(n):
        return '' if n == 0 else to_base_36(n // 36) + "0123456789abcdefghijklmnopqrstuvwxyz"[n % 36]

    # Extract values from packed data
    p, a, c, k = data[0], int(data[1]), int(data[2]), data[3].split('|')

    # Replace placeholders with corresponding values
    for i in range(c):
        if k[c - i - 1]:
            p = re.sub(r'\b' + to_base_36(c - i - 1) + r'\b', k[c - i - 1], p)

    #Get Video URL
    video_url = re.search(r'file:"([^"]+)', p).group(1)
    
    matched_quality = None
    for key, quality in qualities.items():
        if key in video_url:
            matched_quality = quality
            break
    streaming_urls = { matched_quality : video_url }
    
    response_data['status'] = 'success'
    response_data['status_code'] = 200
    response_data['streaming_urls'] = streaming_urls
    response_data['downloading_urls'] = streaming_urls
    return response_data