import requests
from bs4 import BeautifulSoup
import re
from django.http import JsonResponse
import json
import base64
from Crypto.Cipher import Blowfish

default_domain = "https://primewire.tf"
initial_headers = {
    'Referer': default_domain,
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"',
}

response_data = {
    'status': None,
    'status_code': None,
    'error': None,
    'servers': {},
}

proxies = {
    # __ Add your proxies here or use proxy_url __ 
}

# You don't need a proxy if these sites are not blocked in your region.

# Use this if you don't own a proxy it can make proccess longer
proxy_url = f"https://script.google.com/macros/s/AKfycbzo7nCuCR9GWczG2Hk4Uhpstv291rI6pqG9f25sMYkI2R94zURLRNS20blc80MBzh3kOA/exec?header_Referer={default_domain}&header_User-Agent={initial_headers['User-Agent']}"

#Create session
session = requests.Session()

def real_extract(url):
    # Get the embed page
    initial_response = session.get(url, headers = initial_headers, proxies = proxies).text
    
    # Extract encrypted value
    soup = BeautifulSoup(initial_response, "html.parser")
    encrypted_data = soup.find(id="user-data")['v']
    # Extract key (last 10 characters) and data
    key = encrypted_data[-10:].encode()
    data = encrypted_data[:-10]
    
    # Decode the encrypted data from Base64
    encrypted_data = base64.b64decode(data)

    # Initialize Blowfish cipher in ECB mode
    cipher = Blowfish.new(key, Blowfish.MODE_ECB)

    # Perform decryption
    decrypted_data = cipher.decrypt(encrypted_data)

    # Remove padding (assuming NULL bytes were used for padding)
    cleaned_data = decrypted_data.rstrip(b"\x00").decode(errors="ignore")

    # Split the decrypted text into chunks of 1–5 characters for better readability
    chunks = re.findall('.{1,5}', cleaned_data)
    
    # Get the servers and their URLs
    servers = []
    for id in chunks:
        api_url = f"https://www.primewire.tf/links/go/{id}?embed=true"
        response = session.get(api_url, headers=initial_headers, proxies=proxies).json()
        servers.append({"server_name": response["host"], "server_url": response["link"]})
    
    response_data['status'] = 'success'
    response_data['status_code'] = 200
    response_data['servers'] = servers
    return response_data