package com.sabir.appstore;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;


//Array Adapter for ListView and RecyclerView Adapter for RecyclerView
public class AppListAdapter extends ArrayAdapter<AppModel> {
    //Extends ListView Adapter with the Model class

	private Context mContext;
	private ArrayList<AppModel> mAppList;
	private OnItemClickListener mListener; // Interface to get clicked item in the reference class e.g. MainActivity

	public AppListAdapter(Context context, ArrayList<AppModel> appList) {
		super(context, 0, appList);
		mContext = context;
		mAppList = appList;
	} 
	// Public Constructor it required for calling this class
	
	
//Public interface for OnItem click
	public interface OnItemClickListener {
		void onItemClick(int position);
	}

	public void setOnItemClickListener(OnItemClickListener listener) {
		mListener = listener;
	}

	@NonNull
	@Override
	// GetView is default for ListView population 
	public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
		View listItemView = convertView;
		if (listItemView == null) {
			listItemView = LayoutInflater.from(mContext).inflate(R.layout.list_item_layout, parent, false); // Setting layout for each item in the list
		}
		AppModel currentApp = mAppList.get(position); // Iteration over the app list to show each data similar to loop in javascript 

//Getting the view elements for One Data e.g. App
		ImageView mIconView = listItemView.findViewById(R.id.app_icon);
		TextView mAppNameTextView = listItemView.findViewById(R.id.app_name);
		Button mActionButton = listItemView.findViewById(R.id.action_button);
		TextView mAppDescriptionTextView = listItemView.findViewById(R.id.app_description);
		Drawable mAppIcon = currentApp.getDrawable();
		
		// Population the views with data
		mIconView.setImageDrawable(mAppIcon);
		mAppNameTextView.setText(currentApp.getAppName());
		mAppDescriptionTextView.setText(currentApp.getAppDescription());

		mActionButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (mListener != null) {
					mListener.onItemClick(position); // Getting position on which item user clicked 
				}
			}
		});
		// Setting on click listener to each button of data

		return listItemView;
		// Returning the populated data 
	}
}
