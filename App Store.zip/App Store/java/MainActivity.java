package com.sabir.appstore;

import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

	private ArrayList<AppModel> mAppList; // ArrayList for each data(AppModel)
	private ListView mListView;
	private AppListAdapter mAdapter; // Adapter class
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mAppList = new ArrayList<>();
		mListView = findViewById(R.id.app_list);

		mAppList.add(
				new AppModel(1, "GitHub", "Description for App 1", getResources().getDrawable(R.mipmap.ic_launcher)));
		mAppList.add(
				new AppModel(2, "Facebook", "Description for App 2", getResources().getDrawable(R.mipmap.ic_launcher)));
		mAppList.add(
				new AppModel(3, "Whatsapp", "Description for App 3", getResources().getDrawable(R.mipmap.ic_launcher)));
				
				//Adding data to arrayList you can use database(Firebase or Sql) for instance 

		mAdapter = new AppListAdapter(this, mAppList); // Calling adapter class with Data/arrayList 
		mListView.setAdapter(mAdapter);
		// Setting Adapter to ListView 

		mAdapter.setOnItemClickListener(new AppListAdapter.OnItemClickListener() {
			@Override
			public void onItemClick(int position) {
				AppModel clickedApp = mAppList.get(position);
				String appName = clickedApp.getAppName();
				Toast.makeText(MainActivity.this, "Clicked app: " + appName, Toast.LENGTH_SHORT).show();
			}
		});
		
		// OnClick listener getting on which element you clicked you can open a new activity with its ID 

	}
}