package com.sabir.appstore;

import android.content.Intent;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.fragment.app.Fragment;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.navigation.NavigationView.OnNavigationItemSelectedListener;
import android.os.Bundle;
import androidx.drawerlayout.widget.DrawerLayout;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnNavigationItemSelectedListener {

	private Toolbar mToolbar;
	private DrawerLayout mDrawerLayout;
	private FrameLayout mFrameLayout;
	private NavigationView mNavigationView;
	private ImageView mHamburgerButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mToolbar = findViewById(R.id.toolbar);
		mDrawerLayout = findViewById(R.id.drawer_layout_id);
		mFrameLayout = findViewById(R.id.frame_layout);
		mNavigationView = findViewById(R.id.navigation_view_id);
		mHamburgerButton = findViewById(R.id.nav_menu_bar);
		mNavigationView.setNavigationItemSelectedListener(this);

		try {
			toggleDrawer();
			initializeDefaultFragment(savedInstanceState, 0);
		} catch (Exception e) {
			Toast.makeText(MainActivity.this, "ERROR[while setting up Nav Drawer]: " + e.getMessage(),
					Toast.LENGTH_LONG).show();
		}

		mHamburgerButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mDrawerLayout.openDrawer(GravityCompat.START);
			}
		});
	}

	private void initializeDefaultFragment(Bundle bundle, int i) {
		if (bundle == null) {
			onNavigationItemSelected(this.mNavigationView.getMenu().getItem(i).setChecked(true));
		}
	}

	private void toggleDrawer() {
		ActionBarDrawerToggle mActionBarDrawerToggle = new ActionBarDrawerToggle(this, this.mDrawerLayout,
				this.mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
		this.mDrawerLayout.addDrawerListener(mActionBarDrawerToggle);
		mActionBarDrawerToggle.syncState();
		mActionBarDrawerToggle.setDrawerIndicatorEnabled(false);
	}

	public boolean onNavigationItemSelected(MenuItem menuItem) {
		CharSequence charSequence = "This feature is not available";
		switch (menuItem.getItemId()) {
		case R.id.nav_home:
			replaceFragment(new HomeFragment());
			closeDrawer();
			break;
		case R.id.nav_apps:
			replaceFragment(new AppFragment());
			closeDrawer();
			break;
		case R.id.nav_games:
			//Add more fragments
			closeDrawer();
			break;
		case R.id.nav_books:
			//Add more fragments
			closeDrawer();
			break;
		case R.id.nav_profile:
			//Start an activity e.g. startActivity(new Intent(this, Example.class));
			break;
		case R.id.nav_settings:
			//Start an activity e.g. startActivity(new Intent(this, Example.class));
			break;
		case R.id.nav_about:
			//Start an activity e.g. startActivity(new Intent(this, Example.class));
			break;
		}
		return true;

	}

	private void replaceFragment(Fragment fragment) {
		FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
		beginTransaction.replace(R.id.frame_layout, fragment);
		beginTransaction.commit();
	}

	private void closeDrawer() {
		if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
			mDrawerLayout.closeDrawer(GravityCompat.START);
		}
	}

	private void deSelectCheckedState() {
		int size = this.mNavigationView.getMenu().size();
		for (int i = 0; i < size; i++) {
			this.mNavigationView.getMenu().getItem(i).setChecked(false);
		}
	}

}