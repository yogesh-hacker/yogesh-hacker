package com.sabir.appstore;

import android.content.Intent;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

	private ArrayList<AppModel> mAppList;
	private ListView mListView;
	private AppListAdapter mAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mAppList = new ArrayList<>();
		mListView = findViewById(R.id.app_list);

		mAppList.add(
				new AppModel(1, "GitHub", "Description for App 1", getResources().getDrawable(R.mipmap.ic_launcher)));
		mAppList.add(
				new AppModel(2, "Facebook", "Description for App 2", getResources().getDrawable(R.mipmap.ic_launcher)));
		mAppList.add(
				new AppModel(3, "Whatsapp", "Description for App 3", getResources().getDrawable(R.mipmap.ic_launcher)));

		mAdapter = new AppListAdapter(this, mAppList);
		mListView.setAdapter(mAdapter);

		mAdapter.setOnItemClickListener(new AppListAdapter.OnItemClickListener() {
			@Override
			public void onItemClick(int position) {
				AppModel mClickedApp = mAppList.get(position);
				Intent mIntent = new Intent(MainActivity.this, AppDetailsActivity.class);
				mIntent.putExtra("APP_NAME" , mClickedApp.getAppName());
				startActivity(mIntent);
			}
		});

	}
}