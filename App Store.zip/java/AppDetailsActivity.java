package com.sabir.appstore;

import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;

public class AppDetailsActivity extends AppCompatActivity {

	private TextView mResultTextView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_app_details);
		mResultTextView = findViewById(R.id.result);

		String mAppName = getIntent().getStringExtra("APP_NAME");
		mResultTextView.setText("You have clicked:- " + mAppName);

	}
}