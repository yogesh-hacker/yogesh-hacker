package com.sabir.appstore;

import android.app.Application;
import androidx.appcompat.app.AppCompatDelegate;
import android.content.SharedPreferences;
import com.developer.crashx.config.CrashConfig;

public class MyApplication extends Application {
	@Override
	public void onCreate() {
		super.onCreate();
		CrashConfig.Builder.create().backgroundMode(CrashConfig.BACKGROUND_MODE_SHOW_CUSTOM).enabled(true)
				.showErrorDetails(true).showRestartButton(true).logErrorOnRestart(true).trackActivities(true).apply();
	}
}