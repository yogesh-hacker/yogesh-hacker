package com.sabir.appstore;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import java.util.ArrayList;
import android.view.View;

public class HomeFragment extends Fragment {

	private View mView;
	private ArrayList<AppModel> mAppList;
	private ListView mListView;
	private AppListAdapter mAdapter;

	@Nullable
	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
			@Nullable Bundle savedInstanceState) {
		mView = inflater.inflate(R.layout.fragment_home, container, false);

		mAppList = new ArrayList<>();
		mListView = mView.findViewById(R.id.app_list);

		mAppList.add(
				new AppModel(1, "GitHub", "Description for App 1", getResources().getDrawable(R.mipmap.ic_launcher)));
		mAppList.add(
				new AppModel(2, "Facebook", "Description for App 2", getResources().getDrawable(R.mipmap.ic_launcher)));
		mAppList.add(
				new AppModel(3, "Whatsapp", "Description for App 3", getResources().getDrawable(R.mipmap.ic_launcher)));

		mAdapter = new AppListAdapter(getContext(), mAppList);
		mListView.setAdapter(mAdapter);

		mAdapter.setOnItemClickListener(new AppListAdapter.OnItemClickListener() {
			@Override
			public void onItemClick(int position) {
				AppModel mClickedApp = mAppList.get(position);
				Intent mIntent = new Intent(getContext(), AppDetailsActivity.class);
				mIntent.putExtra("APP_NAME", mClickedApp.getAppName());
				startActivity(mIntent);
			}
		});

		return mView;
	}
}