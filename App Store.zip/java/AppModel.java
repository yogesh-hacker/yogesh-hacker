package com.sabir.appstore;

import android.graphics.drawable.Drawable;

public class AppModel {
	private int mAppId;
	private String mAppName;
	private String mAppDescription;
	private Drawable mDrawable;

	public AppModel(int appId, String appName, String appDescription, Drawable drawable) {
		this.mAppId = appId;
		this.mAppName = appName;
		this.mAppDescription = appDescription;
		this.mDrawable = drawable;
	}

	public int getAppId() {
		return mAppId;
	}

	public void setAppId(int appId) {
		this.mAppId = appId;
	}

	public String getAppName() {
		return mAppName;
	}

	public void setAppName(String appName) {
		this.mAppName = appName;
	}

	public String getAppDescription() {
		return mAppDescription;
	}

	public void setAppDescription(String appDescription) {
		this.mAppDescription = appDescription;
	}

	public Drawable getDrawable() {
		return mDrawable;
	}

	public void setDrawable(Drawable drawable) {
		this.mDrawable = drawable;
	}
}
