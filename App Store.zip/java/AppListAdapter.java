package com.sabir.appstore;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;

public class AppListAdapter extends ArrayAdapter<AppModel> {

	private Context mContext;
	private ArrayList<AppModel> mAppList;
	private OnItemClickListener mListener;

	public AppListAdapter(Context context, ArrayList<AppModel> appList) {
		super(context, 0, appList);
		mContext = context;
		mAppList = appList;
	}

	public interface OnItemClickListener {
		void onItemClick(int position);
	}

	public void setOnItemClickListener(OnItemClickListener listener) {
		mListener = listener;
	}

	@NonNull
	@Override
	public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
		View listItemView = convertView;
		if (listItemView == null) {
			listItemView = LayoutInflater.from(mContext).inflate(R.layout.list_item_layout, parent, false);
		}
		AppModel currentApp = mAppList.get(position);

		ImageView mIconView = listItemView.findViewById(R.id.app_icon);
		TextView mAppNameTextView = listItemView.findViewById(R.id.app_name);
		Button mActionButton = listItemView.findViewById(R.id.action_button);
		TextView mAppDescriptionTextView = listItemView.findViewById(R.id.app_description);
		Drawable mAppIcon = currentApp.getDrawable();

		mIconView.setImageDrawable(mAppIcon);
		mAppNameTextView.setText(currentApp.getAppName());
		mAppDescriptionTextView.setText(currentApp.getAppDescription());

		mActionButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (mListener != null) {
					mListener.onItemClick(position);
				}
			}
		});

		return listItemView;
	}
}
